# ═══════════════════════════════════════════════════
# Zamanlanmış Eylem Çalıştırıcı (MACRO)
# ═══════════════════════════════════════════════════

# Hedef oyuncuyu bul ve eylemi çalıştır
$execute as $(exec_player) run function custom_admin:handler/execute/action {id:"$(exec_id)"}

# Feedback
# PERF FIX: Admin log sadece debug modda
$execute if entity @s[tag=gulce_debug] run tellraw @a[tag=gulce_admin] ['',{text:"[GULCE] ",color:"gold",bold:true},{text:"⏰ Çalıştırıldı: ",color:"gray"},{text:"$(exec_id)",color:"yellow"},{text:" → ",color:"gray"},{text:"$(exec_player)",color:"aqua"}]