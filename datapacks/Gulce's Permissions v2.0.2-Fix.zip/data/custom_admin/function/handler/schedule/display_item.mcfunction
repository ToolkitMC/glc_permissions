# ═══════════════════════════════════════════════════
# Zamanlama Item Gösterici (MACRO)
# ═══════════════════════════════════════════════════

# İkon seç
execute unless score #repeat_check gulce_id matches 1 run data modify storage glc:temp temp.icon set value "⏱️"

# Göster
$execute if entity @s[tag=glc.lang_tr] run tellraw @s [{text:"  ",color:"gray"},{nbt:"temp.icon","storage":"glc:temp","interpret":1b},{text:" #$(schedule_id) ",color:"yellow",bold:true},{text:"- ",color:"gray"},{text:"$(action_id)",color:"aqua"},{text:" (",color:"gray"},{text:"$(remaining)",color:"green"},{text:"/",color:"gray"},{text:"$(delay)",color:"yellow"},{text:" tick)",color:"gray"}]
$execute if entity @s[tag=glc.lang_en] run tellraw @s [{text:"  ",color:"gray"},{nbt:"temp.icon","storage":"glc:temp","interpret":1b},{text:" #$(schedule_id) ",color:"yellow",bold:true},{text:"- ",color:"gray"},{text:"$(action_id)",color:"aqua"},{text:" (",color:"gray"},{text:"$(remaining)",color:"green"},{text:"/",color:"gray"},{text:"$(delay)",color:"yellow"},{text:" tick)",color:"gray"}]
