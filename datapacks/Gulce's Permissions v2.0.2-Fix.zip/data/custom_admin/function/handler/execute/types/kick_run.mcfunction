$kick $(selector) $(reason)
